To use eclipse with MCP, just do the following steps:
- Decompile the Minecraft sources
- Open Eclipse
- Select the "eclipse" folder in MCP as workspace
- Create a mod
- You can test the modified client and server in Eclipse, debug
  settings are already prepared to start the game in the IDE
- Recompile and reobfuscate as usual
